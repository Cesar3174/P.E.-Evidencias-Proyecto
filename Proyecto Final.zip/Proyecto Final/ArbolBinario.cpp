#include "ArbolBinario.h"

void ArbolBinario::insertar(Nodo*& nodo, const Jugador& jugador, char criterio) {
    if (!nodo) {
        nodo = new Nodo(jugador);
    } else if ((criterio == 'v' && jugador.valor_actual < nodo->jugador.valor_actual) ||
               (criterio == 'e' && jugador.edad < nodo->jugador.edad) ||
               (criterio == 'n' && jugador.nominaciones < nodo->jugador.nominaciones)) {
        insertar(nodo->izquierda, jugador, criterio);
    } else {
        insertar(nodo->derecha, jugador, criterio);
    }
}

void ArbolBinario::insertar(const Jugador& jugador, char criterio) {
    insertar(raiz, jugador, criterio);
}

void ArbolBinario::inOrden(Nodo* nodo, std::vector<Jugador>& jugadores) const {
    if (nodo) {
        inOrden(nodo->izquierda, jugadores);
        jugadores.push_back(nodo->jugador);
        inOrden(nodo->derecha, jugadores);
    }
}

void ArbolBinario::obtenerOrdenados(std::vector<Jugador>& jugadores) const {
    inOrden(raiz, jugadores);
}

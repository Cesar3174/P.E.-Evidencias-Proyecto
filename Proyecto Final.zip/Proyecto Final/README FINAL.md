# Juan César Nuño Rivera
# Proyecto: 
Mercado de jugadores. En este proyecto lo que se muestra es una lista de jugadores con información sobre ellos como nombre, posición, edad, nominaciiones a premios, y valor de mercado; En este mismo se presentan diversas formas de ordenamiento de esta misma información de acuerdo a lo qque seleccione el usuario

## Descripción del avance 1
Ordenamiento de precio de jugadores de futbol soccer de acuerdo a ciertas características
1. Selección de proceso de ordenamiento el cual queremos utilizar
2. Paso 1: Introducir el nombre del archivo .txt en donde se encontrarán los jugadores 
3. Paso 2: Una vez que se introdujo el nombre, aparecerá un menú, dicho menú nos desplegará 8 opciones, en las cuales estarán las siguientes: 
Actualizar el precio, aumentar la edad de los jugadores, aumentar las nominaciones de premios, ordenar por precio, ordenar por edad, y ordenar por nominaciones, todos estos de menor a mayor, y por último está el mostrar jugadores y salir.
4. Paso 3: Depende de lo que querramos conocer, seleccionaremos dicha opción

Con estos datos podremos ver la comparativa de quien tiene más años, más nominaciones o quien tiene un valor de mercado mayor o menor
En dado caso se requiera agregar más jugadores, o cambiar sus posiciones, se tendría que hacer dicha modificación dentro del archivo de texto

En el avance 1 se mostraba una lista de jugadores, en la cual se podía ver la información de cada uno de ellos (nombre, posición, edad, nominaciiones a premios, y valor de mercado), se podía acceder a esta información por medio de un menú, en el cual podemos incrementar tanto la edad, cambiar el valor de los jugadores e incrementar sus nominaciones a premios, también ordenar por medio de la forma de ordenamiento quick sort a los jugadores depediendo de lo que se haya seleccionado por el usuario (edad, precio, nominaciones)

## Descripción del avance 2
En este avance lo que se realizó fue el mismo ordenamiento en cuanto a las variables, pero ahora por medio de árboles binarios

### Cambios sobre el primer avance
1. Arboles binarios, se decidió implementar esta nueva forma de ordenamiento por considerando lo visto en clase
2. Se añadieron 2 nuevos archivos, ArbolBinario.h y ArbolBinario.cpp, para la implementación de la misma función nueva de arboles binarios
3. Nuevo menú, esta parte se realizó para que el usuario pueda decidir sobre que método de ordenamiento quisiera utilizar, y sobre que variable quiere aplicar dicho método de ordenamiento

## Descripción del avance 3
Se implementó una lista de 100 jugadores en ek archivo jugadores.txt; también se añadió la opción dentro del menú de poder agregar un jugador nuevo; y por último, se implementó el archivo de historial.txt en dado caso no se tenga, se crea por default al correr el programa, en este se gaurdan todos los movimientos realizados

### Cambios sobre el segundo avance
1. Se agregó una lista de 100 jugadores en lugar de solo 8 jugadores
2. Se añade otro archivo llamado movimiento.txt, en dado caso no se tenga aún se crea por si mismo donde se registran todos los movimientos realizados
3. Actualizacion de menú, se agregó la opción de agregar un jugador desde 0

## Entrega final
Corrección de competencias dentro de este README

### Cambios sobre el tercer avance avance
1. Se modificaron, complementaron algunas de las competencias de la parte inferior de este archivo README

## Instrucciones para compilar el proyecto
Ejecuta el siguiente comando en la terminal:
g++ -std=c++11 main.cpp Jugador.cpp Ordenamiento.cpp ArbolBinario.cpp -o programa

## Descripción de las entradas del avance de proyecto
En este caso el programa requiere un archivo .txt para poder funcionar, de donde obtendrá la información de cada uno de los jugadores y por ende el formato o la forma de las varibales deben ser la siguientes: Nombre: String, posición: String, valor: Float, el valor que se presenta está en millones, edad: Entero, nominaciones: Entero 

## Descripción de las salidas del avance de proyecto
En este avance las salidas se presentan de la siguiente manera, al crear un nuevo jugador este se mostrará a la fila de todos los jugadores, en el caso del nuevo archivo de historial.txt se creará el archivo en dado caso no existe, y se mostrarán todos los movimientos realizados en dicho archivo. Y por último toda la lista de los jugadores se mostrarán en dicho archivo.

## Desarrollo de competencias

### SICT0301: Evalúa los componentes
#### Hace un análisis de complejidad correcto y completo para los algoritmos de ordenamiento usados en el programa.
* Jugadores datos del archivo. Función: bool cargarJugadoresDesdeArchivo(const std::string& nombreArchivo, std::vector<Jugador>& jugadores)
En esta función se convierten los datos para crear jugadores y añadirlos al vector.
Y la complejidad sería O(n) donde n son la cantidad de jugadores.

* Actualización del valor jugadores. Función: void Jugador::actualizarValor()
De igual manera esta es O(n) de igual amnera los jugadores es n, cada valor por jugador representa O(1)

* Aumento edad y nominaciones. Función: void Jugador::incrementarEdad() y void Jugador::incrementarNominaciones()
Incrementan en +1 la edad o el número de nominaciones de cada jugador.
Y su complejidad viene siendo O(n) para el aumento de todos los jugades

* Ordenamiento Quick Sort. Función: void quickSortValor(std::vector<Jugador>& jugadores, int bajo, int alto)
void quickSortEdad(std::vector<Jugador>& jugadores, int bajo, int alto)
void quickSortNominaciones(std::vector<Jugador>& jugadores, int bajo, int alto)
Aquí se realiza el ordenamiento de los valores, le edad y las nominaciones.
Cuando el inicio se realiza de manera uniforme hay una complejidad de O(n log n), y en el peor de los casos podría ser O(n^2) pero solo si no se elige correctamente el punto donde se empezará el ordenamiento

* Mostrar Jugadores. Función: void mostrarJugadores(const std::vector<Jugador>& jugadores)
Aquí solo se imprimen los datos de la lista
La complejidad aquí es de O(n), esto porque solamente se recorre una vez el vector

#### Hace un análisis de complejidad correcto y completo de todas las estructuras de datos y cada uno de sus usos en el programa.
En este caso la búsqueda promedio tendría una complejidad O(log n); en el peor de los casos su complejidad sería de O(n) (si el árbol es desbalanceado); y por úlitmo podemos decir que los arboles nos permiten mantener los datos ordenados y realizar búsquedas rápidas, facilita obtener el listado ordenado mediante un recorrido in-order.

#### Hace un análisis de complejidad correcto y completo para todos los demás componentes del programa y determina la complejidad final del programa.
Cargar Jugadores desde un archivo: La función cargarJugadoresDesdeArchivo(const std::string& nombreArchivo, std::vector<Jugador>& jugadores) tiene una complejidad de O(n), donde n es el número de jugadores en el archivo. Esto porque el archivo debe de leerse línea por línea y por cada línea se crea un objeto Jugador, lo que hace que esta operación dependa del número de jugadores en el archivo.

Actualizar Valor de Jugadores: La función void Jugador::actualizarValor() tiene una complejidad O(1) por cada jugador, ya que solo se realiza una actualización de un valor que es un atributo de la clase Jugador. Sin embargo, si esta operación se realiza sobre un conjunto de jugadores, que sería todo el vector la complejidad pasaría a ser de O(n), donde n es el número de jugadores.

Incrementar Edad y Nominaciones: Las funciones void Jugador::incrementarEdad() y void Jugador::incrementarNominaciones() tienen complejidad O(1) por cada jugador, solo incrementa un atributo de la clase. Si se recorren todos los jugadores para realizar esta operación, la complejidad total será O(n).

Ordenamiento Quick Sort: El ordenamiento por Quick Sort, implementado en funciones como void quickSortValor(std::vector<Jugador>& jugadores, int bajo, int alto), tiene una complejidad promedio de O(n log n), donde n es el número de jugadores; en el peor de los casos, la complejidad puede llegar a O(n^2). Dado que los datos son relativamente pequeños de 100 jugadores, el algoritmo Quick Sort es útil y eficiente

Mostrar Jugadores: La función void mostrarJugadores(const std::vector<Jugador>& jugadores) tiene una complejidad de O(n), ya que solo recorre una vez el vector para imprimir los datos de cada jugador.

Insertar en el Árbol Binario: La complejidad de la inserción en un árbol binario balanceado es O(log n), donde n es el número de nodos en el árbol. En el peor caso, si el árbol está desbalanceado, la complejidad podría ser O(n).

Recorrido In-Order: La complejidad de este recorrido es O(n), ya que visita todos los nodos del árbol.

Obtener los Jugadores Ordenados: Si se realiza un recorrido in-order del árbol para obtener los jugadores ordenados, la complejidad sería O(n).

Complejidad Final del Programa: El programa tiene una complejidad que depende de la interacción de varias funciones. La complejidad dominante será O(n log n) debido al algoritmo de ordenamiento Quick Sort. La interacción con el árbol binario, aunque más eficiente en términos de inserción y búsqueda, "no cambia" la compeljidad general
La complejidad del programa es dominada por el O(n log n) del algoritmo de Quick Sort para el ordenamiento, con otras operaciones como la carga de jugadores desde archivo y la visualización de jugadores con complejidades O(n).

### SICT0302: Toma decisiones
#### Selecciona un algoritmo de ordenamiento adecuado al problema y lo usa correctamente.
En este caso podemos decir que el Quick Sort pudiera ser el algoritmo de ordenamiento idóneo, tomando en cuenta que la complejidad de quick sort más común es de O(n log n) considerando que la cantidad de datos no es muy grande; en este primer caso tnego pocos jugadoresy sigue siendo bastante sencillo implementarlo; también dado que estamos evaluando u organizando los datos pro diferentes formas o criterios quick sort nos ayuda a poder cmabiar la función de comparación y poder ordenar de acuerdo al criterio que querramos de manera "sencilla"; por último, considerando que en el peor de los casos su complejidad sería de O(n^2) esto por el tipo de ejercicico o proyecto que estamos realizando podemos "cambiar" el número o dato que se está utilizando como el inicio del proceso de ordenamiento, cambiandolo o utilizando en su lugar el punto medio, al azar y esto ayuda a que sea más rápido 

#### Selecciona una estructura de datos adecuada al problema y la usa correctamente.
En este caso se toma la decisión de seleccionar árboles binarios, en este caso los árboles binarios de búsqueda son una estructura eficiente para mantener los datos ordenados de manera dinámica, la ventaja principal es la capacidad de insertar, eliminar y buscar elementos con una complejidad O(log n) en promedio, lo que es mucho más rápido que los métodos de ordenamiento como Quick Sort, para este caso, el árbol binario de búsqueda es ideal para mantener a los jugadores ordenados por diferentes atributos (edad, nominaciones, valor) y realizar búsquedas rápidas. Si el árbol estuviera desbalanceado, la complejidad podría llegar a O(n)

Se utilizan para recorrer los jugadores en orden in-order, obteniendo una lista de forma ordenada, en este caso es muy útil esta parte porque necesitamos cononcer dicho orden dependiendo de ciergtos atributos como valor, edad, nominaciones.

Y por otro lado, los vectores son adecuados para almacenar y gestionar los jugadores en memoria, los vectores nos permiten el acceso rápido a cualquier elemento por índice, pero las operaciones de inserción o eliminación no son tan eficientes como en los árboles binarios.

De igual manera los vectores nos ayudana  las operaciones como la carga de jugadores desde un archivo o la actualización de atributos, ya que se pueden recorrer rápidamente.

### SICT0303: Implementa acciones científicas
#### Implementa mecanismos para consultar información de las estructras correctos.
Los mecanismos de consulta en el programa nos permiten obtener información de los jugadores

 La función mostrarJugadores() es una función simple que recorre el vector de jugadores y muestra sus atributos en la consola. Aunque esta operación tiene una complejidad de O(n), solo se recorre el vector y se imprimen los datos, lo cual cumple con la generación en este caso de los datos de los jugadores

 Y ahora, la parte de árboles, la función in-order se usa para obtener los jugadores en un orden específico (por valor, edad, nominaciones). Esta operación tiene una complejidad de O(n), ya que se recorre todo el árbol, esto permite obtener los jugadores ordenados de manera rápida.

#### Implementa mecanismos de lectura de archivos para cargar datos a las estructuras de manera correcta.
En este caso, la lectura de datos se realiza por medio de la función cargarJugadoresDesdeArchivo(); lee el archivo que se le proporciona, lee los datos del archivo de texto y l¡descompone la información en nombre, posición, valor, edad y nominaciones; por último crea objetos en Jugador y los almacena en un vector, todo esto asegurando que se carguen los datos de manera correcta para una correcta funcionalidad del prgrama.
### Implementa mecanismos de escritura de archivos para guardar los datos  de las estructuras de manera correcta
Se impleemntan mecanismos de escritura de archivos para guardar los datos porque se crea un archivo de texto en donde se guardan todos los movimientos realizados en el programa, ya sea que no se modifique la lista de jugadores o que se agreguen más jugadores a la lista, todas estas acciones se guardan en dicho archivo (historial.txt)
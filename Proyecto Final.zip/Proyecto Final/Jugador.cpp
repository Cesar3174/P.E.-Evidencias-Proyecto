#include "Jugador.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>

// Constructor
Jugador::Jugador(std::string n, std::string p, float v, int e, int nom)
    : nombre(n), posicion(p), valor_actual(v), edad(e), nominaciones(nom) {
    historial_valor.push_back(v);
}

// Actualización del valor
void Jugador::actualizarValor() {
    float variacion = (rand() % 200 - 100) / 100.0;
    valor_actual += variacion;
    historial_valor.push_back(valor_actual);
}

// Incremento de edad
void Jugador::incrementarEdad() {
    edad++;
}

// Incremento de nominaciones
void Jugador::incrementarNominaciones() {
    nominaciones++;
}

// Cargar jugadores desde archivo
bool cargarJugadoresDesdeArchivo(const std::string& nombreArchivo, std::vector<Jugador>& jugadores) {
    std::ifstream archivo(nombreArchivo);
    if (!archivo.is_open()) {
        std::cerr << "No se pudo abrir el archivo: " << nombreArchivo << std::endl;
        return false;
    }

    std::string linea;
    while (std::getline(archivo, linea)) {
        std::stringstream ss(linea);
        std::string nombre, posicion, valor_str, edad_str, nominaciones_str;
        float valor;
        int edad, nominaciones;

        std::getline(ss, nombre, ',');
        std::getline(ss, posicion, ',');
        std::getline(ss, valor_str, ',');
        std::getline(ss, edad_str, ',');
        std::getline(ss, nominaciones_str);

        valor = std::stof(valor_str);
        edad = std::stoi(edad_str);
        nominaciones = std::stoi(nominaciones_str);

        jugadores.emplace_back(nombre, posicion, valor, edad, nominaciones);
    }

    archivo.close();
    return true;
}

// Mostrar jugadores
void mostrarJugadores(const std::vector<Jugador>& jugadores) {
    for (const auto& jugador : jugadores) {
        std::cout << "Nombre: " << jugador.nombre
                  << ", Posición: " << jugador.posicion
                  << ", Valor: " << jugador.valor_actual
                  << ", Edad: " << jugador.edad
                  << ", Nominaciones: " << jugador.nominaciones << std::endl;
    }
}

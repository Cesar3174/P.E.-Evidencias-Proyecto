#ifndef ORDENAMIENTO_H
#define ORDENAMIENTO_H

#include "Jugador.h"
#include <vector>

void quickSortValor(std::vector<Jugador>& jugadores, int inicio, int fin);
void quickSortEdad(std::vector<Jugador>& jugadores, int inicio, int fin);
void quickSortNominaciones(std::vector<Jugador>& jugadores, int inicio, int fin);

#endif

#include "Ordenamiento.h"

void quickSortValor(std::vector<Jugador>& jugadores, int inicio, int fin) {
    // Implementación de QuickSort basada en valor
}

void quickSortEdad(std::vector<Jugador>& jugadores, int inicio, int fin) {
    // Implementación de QuickSort basada en edad
}

void quickSortNominaciones(std::vector<Jugador>& jugadores, int inicio, int fin) {
    // Implementación de QuickSort basada en nominaciones
}


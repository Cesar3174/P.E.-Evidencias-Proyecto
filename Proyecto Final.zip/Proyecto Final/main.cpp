#include <iostream>
#include <vector>
#include <fstream>
#include <ctime>
#include <limits>
#include "Jugador.h"
#include "Ordenamiento.h"
#include "ArbolBinario.h"

void guardarHistorial(const std::string& nombreArchivo, const std::vector<Jugador>& jugadores) {
    std::ofstream archivo(nombreArchivo, std::ios::app);
    if (!archivo.is_open()) {
        std::cerr << "No se pudo abrir el archivo de historial.\n";
        return;
    }
    archivo << "\nEstado actual de los jugadores:\n";
    for (const auto& jugador : jugadores) {
        archivo << jugador.nombre << "," << jugador.posicion << ","
                << jugador.valor_actual << "," << jugador.edad << ","
                << jugador.nominaciones << "\n";
    }
    archivo.close();
}

std::string pedirNombreArchivo() {
    std::string nombreArchivo;
    while (true) {
        std::cout << "Introduce el nombre del archivo de jugadores (con extensión .txt): ";
        std::cin >> nombreArchivo;
        std::ifstream archivo(nombreArchivo);
        if (archivo.is_open()) {
            archivo.close();
            break;
        } else {
            std::cerr << "No se pudo abrir el archivo. Intenta de nuevo.\n";
        }
    }
    return nombreArchivo;
}

int pedirEntero(const std::string& mensaje) {
    int valor;
    while (true) {
        std::cout << mensaje;
        std::cin >> valor;
        if (!std::cin.fail()) break;
        
        std::cout << "Entrada inválida. Introduce un número entero.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    return valor;
}

float pedirFloat(const std::string& mensaje) {
    float valor;
    while (true) {
        std::cout << mensaje;
        std::cin >> valor;
        if (!std::cin.fail()) break;
        
        std::cout << "Entrada inválida. Introduce un número decimal.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
    return valor;
}

int main() {
    srand(time(0));
    std::vector<Jugador> jugadores;
    std::string historialArchivo = "historial_movimientos.txt";

    // Cargar el archivo de jugadores
    std::string nombreArchivo = pedirNombreArchivo();
    if (!cargarJugadoresDesdeArchivo(nombreArchivo, jugadores)) {
        std::cerr << "Error al cargar los jugadores desde el archivo." << std::endl;
        return 1;
    }

    int opcion;
    do {
        std::cout << "\n1. Actualizar precios de jugadores\n";
        std::cout << "2. Incrementar edad\n";
        std::cout << "3. Incrementar nominaciones\n";
        std::cout << "4. Ordenar por valor (Quick Sort)\n";
        std::cout << "5. Ordenar por edad (Quick Sort)\n";
        std::cout << "6. Ordenar por nominaciones (Quick Sort)\n";
        std::cout << "7. Ordenar por valor (Árbol Binario)\n";
        std::cout << "8. Ordenar por edad (Árbol Binario)\n";
        std::cout << "9. Ordenar por nominaciones (Árbol Binario)\n";
        std::cout << "10. Agregar nuevo jugador\n";
        std::cout << "11. Mostrar jugadores\n";
        std::cout << "0. Salir\n";
        std::cout << "Elige una opción: ";
        std::cin >> opcion;

        switch (opcion) {
            case 1:
                for (auto& jugador : jugadores) {
                    jugador.actualizarValor();
                }
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Precios actualizados.\n";
                break;
            case 2:
                for (auto& jugador : jugadores) {
                    jugador.incrementarEdad();
                }
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Edad incrementada.\n";
                break;
            case 3:
                for (auto& jugador : jugadores) {
                    jugador.incrementarNominaciones();
                }
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Nominaciones incrementadas.\n";
                break;
            case 4:
                quickSortValor(jugadores, 0, jugadores.size() - 1);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por valor (Quick Sort).\n";
                break;
            case 5:
                quickSortEdad(jugadores, 0, jugadores.size() - 1);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por edad (Quick Sort).\n";
                break;
            case 6:
                quickSortNominaciones(jugadores, 0, jugadores.size() - 1);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por nominaciones (Quick Sort).\n";
                break;
            case 7: {
                ArbolBinario arbolValor;
                for (const auto& jugador : jugadores) {
                    arbolValor.insertar(jugador, 'v');
                }
                jugadores.clear();
                arbolValor.obtenerOrdenados(jugadores);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por valor (Árbol Binario).\n";
                break;
            }
            case 8: {
                ArbolBinario arbolEdad;
                for (const auto& jugador : jugadores) {
                    arbolEdad.insertar(jugador, 'e');
                }
                jugadores.clear();
                arbolEdad.obtenerOrdenados(jugadores);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por edad (Árbol Binario).\n";
                break;
            }
            case 9: {
                ArbolBinario arbolNominaciones;
                for (const auto& jugador : jugadores) {
                    arbolNominaciones.insertar(jugador, 'n');
                }
                jugadores.clear();
                arbolNominaciones.obtenerOrdenados(jugadores);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugadores ordenados por nominaciones (Árbol Binario).\n";
                break;
            }
            case 10: {
                std::string nombre, posicion;
                std::cout << "Introduce el nombre del jugador: ";
                std::cin >> nombre;
                std::cout << "Introduce la posición del jugador: ";
                std::cin >> posicion;
                float valor = pedirFloat("Introduce el valor del jugador: ");
                int edad = pedirEntero("Introduce la edad del jugador: ");
                int nominaciones = pedirEntero("Introduce el número de nominaciones del jugador: ");

                jugadores.emplace_back(nombre, posicion, valor, edad, nominaciones);
                guardarHistorial(historialArchivo, jugadores);
                std::cout << "Jugador agregado y guardado en el historial.\n";
                break;
            }
            case 11:
                mostrarJugadores(jugadores);
                break;
            case 0:
                std::cout << "Saliendo del programa...\n";
                break;
            default:
                std::cout << "Opción incorrecta, intenta de nuevo.\n";
                break;
        }
    } while (opcion != 0);

    return 0;
}

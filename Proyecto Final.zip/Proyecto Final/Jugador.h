#ifndef JUGADOR_H
#define JUGADOR_H

#include <string>
#include <vector>

struct Jugador {
    std::string nombre;
    std::string posicion;
    float valor_actual;
    int edad;
    int nominaciones;
    std::vector<float> historial_valor;

    Jugador(std::string n, std::string p, float v, int e, int nom);
    void actualizarValor();
    void incrementarEdad();
    void incrementarNominaciones();
};

bool cargarJugadoresDesdeArchivo(const std::string& nombreArchivo, std::vector<Jugador>& jugadores); 
void mostrarJugadores(const std::vector<Jugador>& jugadores);

#endif
#ifndef ARBOLBINARIO_H
#define ARBOLBINARIO_H

#include "Jugador.h"
#include <vector>

class Nodo {
public:
    Jugador jugador;
    Nodo* izquierda;
    Nodo* derecha;

    Nodo(const Jugador& j) : jugador(j), izquierda(nullptr), derecha(nullptr) {}
};

class ArbolBinario {
private:
    Nodo* raiz;
    void insertar(Nodo*& nodo, const Jugador& jugador, char criterio);
    void inOrden(Nodo* nodo, std::vector<Jugador>& jugadores) const;
public:
    ArbolBinario() : raiz(nullptr) {}
    void insertar(const Jugador& jugador, char criterio);
    void obtenerOrdenados(std::vector<Jugador>& jugadores) const;
};

#endif

